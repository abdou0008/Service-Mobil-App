const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Reservation, Review } = require('./models');

// Authentification
exports.register = async (req, res) => {
    const { email, password, role } = req.body;
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    try {
        const user = new User({ email, password: hashedPassword, role });
        await user.save();
        res.status(201).json({ message: 'User created successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Email not found' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ message: 'Invalid password' });

    const token = jwt.sign({ _id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
};

// Réservations
exports.createReservation = async (req, res) => {
    const { professionalId, service, date } = req.body;
    try {
        const reservation = new Reservation({ user: req.user._id, professional: professionalId, service, date });
        await reservation.save();
        res.status(201).json(reservation);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getPastReservations = async (req, res) => {
    try {
      const userId = req.user.id; // ID de l'utilisateur récupéré via le middleware d'authentification JWT
  
      const reservations = await Reservation.find({
        userId: userId,
        status: 'completed' // Filtre pour les réservations terminées
      }).populate('serviceId', 'name description'); // Populate pour inclure les détails du service
  
      res.status(200).json({
        success: true,
        data: reservations
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Erreur lors de la récupération des réservations passées',
        error: error.message
      });
    }
  };

// Avis
exports.addReview = async (req, res) => {
    const { professionalId, rating, comment } = req.body;
    try {
        const review = new Review({ user: req.user._id, professional: professionalId, rating, comment });
        await review.save();
        res.status(201).json(review);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Catalogue
exports.getProfessionals = async (req, res) => {
    try {
        const professionals = await User.find({ role: 'professional' }).select('-password');
        res.json(professionals);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
