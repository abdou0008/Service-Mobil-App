const mongoose = require('mongoose');

// Modèle de l'utilisateur
const UserSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['user', 'professional'], default: 'user' },
    profile: {
        name: String,
        rating: Number,
        reviews: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Review' }]
    }
});

// Modèle pour les réservations
const ReservationSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    professional: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service',
        required: true
      },
    date: Date,
    status: { type: String, enum: ['pending', 'confirmed', 'cancelled'], default: 'pending' },
    createdAt: {
        type: Date,
        default: Date.now
      }
});

// Modèle pour les avis
const ReviewSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    professional: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    rating: { type: Number, min: 1, max: 5 },
    comment: String
});

const ServiceSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    category: { type: String, required: true }, // Catégorie du service, ex : coiffure, nettoyage, etc.
    price: { type: Number, required: true },
    professional: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // L'utilisateur professionnel offrant ce service
    createdAt: { type: Date, default: Date.now }
});

module.exports = {
    User: mongoose.model('User', UserSchema),
    Reservation: mongoose.model('Reservation', ReservationSchema),
    Review: mongoose.model('Review', ReviewSchema),
    Service: mongoose.model('Service', ServiceSchema)
};
