const express = require('express');
const controllers = require('./controllers');
const { authenticateToken } = require('./middlewares');

const router = express.Router();

// Auth routes
router.post('/register', controllers.register);
router.post('/login', controllers.login);

// Professional catalogue
router.get('/professionals', controllers.getProfessionals);

// Reservation routes
router.post('/reservations', authenticateToken, controllers.createReservation);

// Past Reservation routes
router.get('/past', authenticateToken, controllers.getPastReservations);


// Review routes
router.post('/reviews', authenticateToken, controllers.addReview);

module.exports = router;
